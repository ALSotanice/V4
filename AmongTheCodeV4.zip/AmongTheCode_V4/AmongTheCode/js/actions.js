function openModal(m) { S.modal = m; render(); }
function closeModal()  { S.modal = null; render(); }

function doCreateRoom() {
    const nameEl = document.getElementById('my-name');
    if (nameEl) S.myName = nameEl.value.trim() || S.myName;

    S.roomId     = S.peerId;
    S.roomName   = document.getElementById('cr-name')?.value || 'My Room';
    S.maxPlayers = Math.min(5, Math.max(2, parseInt(document.getElementById('cr-max')?.value) || 5));
    S.isHost     = true;
    S.players    = [{ peerId: S.peerId || 'local', name: S.myName, color: S.myColor, avatar: S.myAvatar, isHost: true, readyVote: false }];
    S.chatMessages = [];
    S.modal        = null;
    S.phase        = 'waiting';
    notify('✅ Phòng "' + S.roomName + '" đã tạo!');
    render();
}

function doJoinRoom() {
    const nameEl = document.getElementById('my-name');
    if (nameEl) S.myName = nameEl.value.trim() || S.myName;

    const hostId = (document.getElementById('join-peer-id')?.value || '').trim();
    const nick   = (document.getElementById('join-name')?.value    || S.myName).trim();

    if (!hostId) { notify('❌ Nhập Room ID của host!', true); return; }
    if (hostId === S.peerId) { notify('❌ Đó là ID phòng của chính bạn!', true); return; }

    S.myName = nick;
    S.modal  = null;
    render();

    notify('🔌 Đang kết nối tới phòng...');
    connectToPeer(hostId, conn => {
        conn.send({ type: 'JOIN_REQUEST', name: S.myName, color: S.myColor, avatar: S.myAvatar });
    });
}

function prefillJoin(id) {
    openModal('join');
    setTimeout(() => {
        const el = document.getElementById('join-peer-id');
        if (el) el.value = id;
    }, 40);
}

function quickGame() {
    notify('⚡ Quick game: Tạo phòng mới để thử...');
    setTimeout(() => openModal('create'), 600);
}

function doExitRoom() {
    cleanupRoom();
    S.phase = 'lobby';
    render();
}

function doHostStart() {
    if (!S.isHost) return;
    sendToAll({ type: 'START_COUNTDOWN' });
    startCountdown();
}

function doVoteStart() {
    const host = S.players.find(p => p.isHost);
    if (host && host.peerId !== S.peerId) {
        sendTo(host.peerId, { type: 'VOTE_REQUEST' });
        notify('🗳️ Đã gửi vote bắt đầu sớm');
    } else {
        doHostStart();
    }
}

function doSaveSettings() {
    const rt = parseInt(document.getElementById('s-round')?.value)   || 60;
    const mt = parseInt(document.getElementById('s-meeting')?.value) || 30;
    S.roundTime   = rt;
    S.meetingTime = mt;
    sendToAll({ type: 'SETTINGS_UPDATE', roundTime: rt, meetingTime: mt });
    notify('✅ Đã chỉnh sửa thành công!');
    closeModal();
}

function doSendChat() {
    const el = document.getElementById('chat-in');
    if (!el || !el.value.trim()) return;
    broadcastChat(el.value.trim());
    el.value = '';
}

function doSendMeetingChat() {
    if (S.isSpectator) return;
    const el = document.getElementById('mc-in');
    if (!el || !el.value.trim()) return;
    const msg   = el.value.trim();
    const entry = { from: S.myName, msg, color: S.myColor };
    el.value = '';

    S.meetingChatMessages.push(entry);
    sendToAll({ type: 'MEETING_CHAT', ...entry });

    const scroll = document.getElementById('meeting-chat-scroll');
    if (scroll) {
        const div = document.createElement('div');
        div.style.fontSize = '10px';
        div.innerHTML = `<span style="color:${entry.color};">${entry.from}:</span> <span style="color:#d4d4d4;">${entry.msg}</span>`;
        scroll.appendChild(div);
        scroll.scrollTop = scroll.scrollHeight;
    }
}

function doRunCode() {
    const fi  = FILES[S.currentFile];
    let out   = `> vscode-terminal: ${S.currentFile} (${fi.lang.toUpperCase()})\n\n🔨 Compiling ${fi.lang}...\n`;
    if (Math.random() < 0.3) {
        out += `❌ Error: Unexpected token\n(Generic compilation failure)\n`;
    } else {
        out += `✅ Compiled successfully!\n🚀 Executing...\n`;
        const fake = { javascript: '🎮 "Game started!"', python: '🎮 Hello from Python', java: '🎮 Hello Java Game!', cpp: '🎮 Hello C++!' };
        out += (fake[fi.lang] || 'Output: Game running!') + '\n\nProcess exited with code 0';
    }
    S.terminalOutput = out;
    S.showTerminal   = true;
    render();
}

function doOpenMeeting() {
    if (S.isSpectator) return;
    requestMeeting();
}

function doConfirmVote() {
    if (S.isSpectator) return;
    S.hasVoted = true;
    render();
    submitVote(S.selectedVote || null);
}

function doSkipVote() {
    if (S.isSpectator) return;
    S.hasVoted = true;
    render();
    submitVote(null);
}