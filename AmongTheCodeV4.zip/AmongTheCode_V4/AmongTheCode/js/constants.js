const COLORS  = ['#22c55e', '#ef4444', '#3b82f6', '#f59e0b', '#a855f7'];
const AVATARS = ['👾', '🔴', '🔵', '🟡', '🟣'];

const FILES = {
    'main.game.js': {
        content: `let score = null;
let playerName = "";
let isRunning = false;

function initPlayer(name) {

}

function gameLoop() {

}

function onCollision(a, b) {
    return a.x === b.x && a.y === b.y;
}`,
        lang: 'javascript',
        icon: '🟦'
    },
    'script.py': {
        content: `class GameState:

    def __init__(self):
        self.players = []
        self.round = 1

def check_winner(state):

    pass

def run_game():
    state = GameState()
    return state`,
        lang: 'python',
        icon: '🐍'
    },
    'Main.java': {
        content: `import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        PlayerManager pm = new PlayerManager();
        System.out.println(pm.toString());
    }
}

class PlayerManager {
    private List<String> players = new ArrayList<>();

    public void addPlayer(String name) {
        players.add(name);
    }

    public String toString() {

    }
}`,
        lang: 'java',
        icon: '☕'
    },
    'game.cpp': {
        content: `#include <iostream>
#include <vector>
#include <string>

struct Player {

};

std::vector<Player> players;

void update() {

}

int main() {
    update();
    std::cout << "Game running" << std::endl;
    return 0;
}`,
        lang: 'cpp',
        icon: '⚙️'
    }
};

const PUBLIC_ROOMS = [
    { id: '123456', name: 'Battle Royale #001', cur: 3, max: 5 },
    { id: '789012', name: 'Code Duel #042',     cur: 1, max: 5 },
    { id: '345678', name: 'Speed Code VIP',     cur: 4, max: 5 },
];