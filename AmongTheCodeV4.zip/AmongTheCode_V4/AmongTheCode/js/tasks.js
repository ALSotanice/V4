const TASKS_DEVELOPER = {
    'main.game.js': [
        { id: 'js-1', label: 'Viết hàm initPlayer(name)' },
        { id: 'js-2', label: 'Thêm vòng lặp gameLoop()' },
        { id: 'js-3', label: 'Khai báo biến score = 0' },
    ],
    'script.py': [
        { id: 'py-1', label: 'Tạo class GameState' },
        { id: 'py-2', label: 'Viết hàm check_winner()' },
    ],
    'Main.java': [
        { id: 'java-1', label: 'Implement PlayerManager class' },
        { id: 'java-2', label: 'Override phương thức toString()' },
    ],
    'game.cpp': [
        { id: 'cpp-1', label: 'Khai báo struct Player { }' },
        { id: 'cpp-2', label: 'Viết hàm update() mỗi frame' },
    ],
};

const TASKS_INJECTOR = {
    'main.game.js': [
        { id: 'injs-1', label: 'Thêm while(true){} ẩn vào hàm bất kỳ' },
        { id: 'injs-2', label: 'Đổi biến score thành s0re' },
    ],
    'script.py': [
        { id: 'inpy-1', label: 'Sửa return True thành return False' },
        { id: 'inpy-2', label: 'Thêm import thừa gây lỗi module' },
    ],
    'Main.java': [
        { id: 'injava-1', label: 'Xóa throws Exception khỏi method' },
        { id: 'injava-2', label: 'Comment out dòng return quan trọng' },
    ],
    'game.cpp': [
        { id: 'incpp-1', label: 'Thêm delete ptr sau khi đã dùng' },
        { id: 'incpp-2', label: 'Đổi <= thành < trong vòng lặp' },
    ],
};

function initTasks() {
    const source = S.myRole === 'injector' ? TASKS_INJECTOR : TASKS_DEVELOPER;
    S.tasks = {};
    Object.keys(source).forEach(fn => {
        S.tasks[fn] = source[fn].map(t => ({ ...t, done: false }));
    });
    S.completedTaskIds     = new Set();
    S.allCompletedDevTasks = new Set();  // aggregate from all players
    S.allCompletedInjTasks = new Set();  // aggregate from injector(s)
    S.totalDevTasks = Object.values(TASKS_DEVELOPER).reduce((a, arr) => a + arr.length, 0);
    S.taskProgress = 0;
}

function toggleTask(taskId) {
    let found = false;
    Object.keys(S.tasks).forEach(fn => {
        S.tasks[fn].forEach(t => {
            if (t.id === taskId) {
                t.done = !t.done;
                found  = true;
                if (t.done) {
                    S.completedTaskIds.add(taskId);
                    // Cập nhật aggregate sets theo role
                    if (S.myRole === 'injector') {
                        S.allCompletedInjTasks.add(taskId);
                    } else {
                        S.allCompletedDevTasks.add(taskId);
                    }
                    // Broadcast cho các player khác
                    if (typeof sendToAll === 'function') {
                        sendToAll({ type: 'TASK_COMPLETED', taskId, role: S.myRole, peerId: S.peerId });
                    }
                } else {
                    S.completedTaskIds.delete(taskId);
                    if (S.myRole === 'injector') {
                        S.allCompletedInjTasks.delete(taskId);
                    } else {
                        S.allCompletedDevTasks.delete(taskId);
                    }
                    if (typeof sendToAll === 'function') {
                        sendToAll({ type: 'TASK_UNCOMPLETED', taskId, role: S.myRole, peerId: S.peerId });
                    }
                }
            }
        });
    });
    if (!found) return;

    if (S.myRole === 'developer' || S.isSpectator) {
        const completed = [...S.completedTaskIds].filter(id => !id.startsWith('in')).length;
        S.taskProgress = S.totalDevTasks > 0 ? Math.round((completed / S.totalDevTasks) * 100) : 0;
    }
    patchProgressBar();
    patchTaskList();
}

/** Nhận task update từ peer khác */
function handleRemoteTaskCompleted(data) {
    if (!data || !data.taskId) return;
    if (data.role === 'injector') {
        (S.allCompletedInjTasks = S.allCompletedInjTasks || new Set()).add(data.taskId);
    } else {
        (S.allCompletedDevTasks = S.allCompletedDevTasks || new Set()).add(data.taskId);
    }
}

function handleRemoteTaskUncompleted(data) {
    if (!data || !data.taskId) return;
    if (data.role === 'injector') {
        (S.allCompletedInjTasks = S.allCompletedInjTasks || new Set()).delete(data.taskId);
    } else {
        (S.allCompletedDevTasks = S.allCompletedDevTasks || new Set()).delete(data.taskId);
    }
}

function patchProgressBar() {
    const bar  = document.getElementById('task-progress-fill');
    const pct  = document.getElementById('task-progress-pct');
    const note = document.getElementById('task-progress-note');
    if (bar)  bar.style.width = S.taskProgress + '%';
    if (pct)  pct.textContent = S.taskProgress + '%';
    if (note) {
        note.textContent = S.taskProgress >= 100 ? '🎉 Hoàn thành 100%!' : '';
        note.style.color = '#22c55e';
    }
}

function patchTaskList() {
    const container = document.getElementById('task-list-container');
    if (!container) return;
    container.innerHTML = (S.tasks[S.currentFile] || []).map(t => buildTaskRow(t)).join('');
}

function buildTaskRow(t) {
    return `
    <div style="display:flex;align-items:flex-start;gap:8px;padding:6px 0;border-bottom:1px solid #1a1a1a;">
        <div onclick="toggleTask('${t.id}')"
            style="width:16px;height:16px;border-radius:4px;flex-shrink:0;cursor:pointer;margin-top:1px;
            border:1px solid ${t.done ? '#22c55e' : '#444'};background:${t.done ? '#22c55e' : 'transparent'};
            display:flex;align-items:center;justify-content:center;font-size:10px;">
            ${t.done ? '✓' : ''}
        </div>
        <div style="font-size:10px;line-height:1.4;color:${t.done ? '#555' : '#ccc'};
            text-decoration:${t.done ? 'line-through' : 'none'};">${t.label}</div>
    </div>`;
}