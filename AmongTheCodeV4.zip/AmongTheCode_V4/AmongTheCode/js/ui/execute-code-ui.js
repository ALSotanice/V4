/* ============================================================
   ui/execute-code-ui.js  [UI + LOGIC]
   Màn hình "Executing Code" hiển thị 10 giây trước khi vào
   Meeting Phase.

   Hiển thị kết quả chạy từng file dựa trên:
     - Developer tasks đã hoàn thành → ✅ file OK → tiến độ cộng
     - Injector tasks đã hoàn thành trên file đó → ❌ file lỗi
       → thanh tiến độ KHÔNG cập nhật cho file đó

   Flow:
     startExecuteScreen() →  10s countdown → enterMeetingPhase()
   ============================================================ */

/**
 * Tính trạng thái từng file khi execute:
 * Trả về object { filename: { devDone, injDone, status, tasks } }
 *
 * status:
 *   'ok'      — có ít nhất 1 dev task done, không bị inject
 *   'error'   — có injector task done trên file này
 *   'pending' — chưa có dev task nào done
 */
function computeExecuteResults() {
    const results = {};

    Object.keys(FILES).forEach(fn => {
        // Collect completed dev task ids for this file
        const devTasksDone = (TASKS_DEVELOPER[fn] || []).filter(t => {
            // Check across ALL players' completed tasks (broadcast via network)
            // Locally we use S.allCompletedDevTasks (aggregated)
            return (S.allCompletedDevTasks || S.completedTaskIds || new Set()).has(t.id);
        });

        // Collect completed injector task ids for this file
        const injTasksDone = (TASKS_INJECTOR[fn] || []).filter(t => {
            return (S.allCompletedInjTasks || new Set()).has(t.id);
        });

        let status = 'pending';
        if (injTasksDone.length > 0) {
            status = 'error';       // file bị sabotage — override mọi thứ
        } else if (devTasksDone.length > 0) {
            status = 'ok';
        }

        results[fn] = {
            devDone:  devTasksDone.length,
            devTotal: (TASKS_DEVELOPER[fn] || []).length,
            injDone:  injTasksDone.length,
            status,
            icon:     FILES[fn].icon || '📄',
            lang:     FILES[fn].lang || '',
        };
    });

    return results;
}

/**
 * Áp dụng kết quả execute vào S.taskProgress:
 * Chỉ file 'ok' mới đóng góp vào thanh tiến độ chung.
 */
function applyExecuteResultsToProgress(results) {
    let totalDev = 0;
    let validDone = 0;

    Object.keys(results).forEach(fn => {
        const r = results[fn];
        totalDev  += r.devTotal;
        if (r.status === 'ok') {
            validDone += r.devDone;
        }
        // nếu status === 'error' → devDone KHÔNG được tính
    });

    S.taskProgress = totalDev > 0 ? Math.round((validDone / totalDev) * 100) : 0;
    patchProgressBar();
}

// ── State for execute screen ──────────────────────────────────
let _executeTimer    = null;
let _executeResults  = null;

/**
 * Khởi động màn hình Execute Code.
 * Gọi thay vì vào meeting trực tiếp.
 * @param {Function} afterCallback  — gọi khi màn hình kết thúc (→ meeting)
 */
function startExecuteScreen(afterCallback) {
    if (_executeTimer) { clearInterval(_executeTimer); _executeTimer = null; }

    _executeResults = computeExecuteResults();
    applyExecuteResultsToProgress(_executeResults);

    S.showExecuteScreen   = true;
    S.executeScreenSecs   = 10;
    S._executeAfterCb     = afterCallback || null;
    render();

    _executeTimer = setInterval(() => {
        S.executeScreenSecs--;

        // patch only the countdown number for perf
        const el = document.getElementById('exec-countdown');
        if (el) el.textContent = S.executeScreenSecs + 's';

        if (S.executeScreenSecs <= 0) {
            clearInterval(_executeTimer);
            _executeTimer = null;
            S.showExecuteScreen = false;
            render();
            if (S._executeAfterCb) S._executeAfterCb();
        }
    }, 1000);
}

/**
 * Người dùng bấm "Skip" — bỏ qua màn hình execute sớm.
 */
function skipExecuteScreen() {
    if (_executeTimer) { clearInterval(_executeTimer); _executeTimer = null; }
    S.showExecuteScreen = false;
    render();
    if (S._executeAfterCb) S._executeAfterCb();
}

// ── Render ────────────────────────────────────────────────────
function renderExecuteScreen() {
    if (!S.showExecuteScreen || !_executeResults) return '';

    const results = _executeResults;
    const secs    = S.executeScreenSecs;

    // Build file rows
    const fileRows = Object.keys(results).map(fn => {
        const r = results[fn];
        let statusIcon, statusColor, statusText, bgColor, borderColor;

        if (r.status === 'ok') {
            statusIcon  = '✅';
            statusColor = '#22c55e';
            statusText  = `Passed — ${r.devDone}/${r.devTotal} tasks`;
            bgColor     = 'rgba(34,197,94,0.08)';
            borderColor = '#22c55e44';
        } else if (r.status === 'error') {
            statusIcon  = '❌';
            statusColor = '#ef4444';
            statusText  = `ERROR — File bị sabotage! (${r.injDone} inject)`;
            bgColor     = 'rgba(239,68,68,0.1)';
            borderColor = '#ef444444';
        } else {
            statusIcon  = '⏳';
            statusColor = '#858585';
            statusText  = `No tasks completed`;
            bgColor     = 'rgba(255,255,255,0.02)';
            borderColor = '#333';
        }

        // Simulated "output lines" per file for visual effect
        const fakeLines = generateFakeOutput(fn, r);

        return `
        <div style="background:${bgColor};border:1px solid ${borderColor};border-radius:10px;
            padding:12px 16px;margin-bottom:10px;animation:fadeInRow 0.3s ease;">
            <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">
                <span style="font-size:18px;">${r.icon}</span>
                <span style="font-size:13px;color:#d4d4d4;font-weight:600;flex:1;">${fn}</span>
                <span style="font-size:11px;color:#555;text-transform:uppercase;letter-spacing:0.08em;">
                    ${r.lang}
                </span>
                <span style="font-size:18px;">${statusIcon}</span>
                <span style="font-size:11px;color:${statusColor};font-weight:500;">${statusText}</span>
            </div>
            <div style="background:#0d0d0d;border-radius:6px;padding:8px 10px;
                font-family:'JetBrains Mono',monospace;font-size:10px;color:#858585;
                line-height:1.6;max-height:70px;overflow:hidden;">
                ${fakeLines}
            </div>
        </div>`;
    }).join('');

    // Progress summary
    const prog = S.taskProgress;
    const progColor = prog >= 80 ? '#22c55e' : prog >= 40 ? '#f59e0b' : '#ef4444';

    return `
    <div style="position:fixed;inset:0;background:rgba(0,0,0,0.96);z-index:5000;
        display:flex;align-items:center;justify-content:center;
        animation:modalPop 0.2s ease;">

        <div style="width:640px;max-width:95vw;max-height:90vh;overflow-y:auto;
            background:#141414;border:1px solid #333;border-radius:16px;
            padding:24px;box-shadow:0 24px 80px rgba(0,0,0,0.8);">

            <!-- Header -->
            <div style="display:flex;align-items:center;gap:12px;margin-bottom:20px;">
                <div style="font-size:22px;">⚡</div>
                <div style="flex:1;">
                    <div style="font-size:16px;color:#d4d4d4;font-weight:700;
                        font-family:'JetBrains Mono',monospace;">
                        Executing Code...
                    </div>
                    <div style="font-size:11px;color:#555;margin-top:2px;">
                        Kiểm tra tiến độ trước khi vào cuộc họp
                    </div>
                </div>
                <!-- Countdown ring -->
                <div style="width:56px;height:56px;border-radius:50%;
                    border:3px solid #f59e0b;display:flex;align-items:center;
                    justify-content:center;flex-direction:column;
                    box-shadow:0 0 20px #f59e0b44;">
                    <div id="exec-countdown"
                        style="font-size:18px;color:#f59e0b;font-weight:700;
                        font-family:'JetBrains Mono',monospace;line-height:1;">
                        ${secs}s
                    </div>
                </div>
            </div>

            <!-- File results -->
            <div style="margin-bottom:16px;">
                ${fileRows}
            </div>

            <!-- Overall progress bar -->
            <div style="background:#1e1e1e;border:1px solid #2a2a2a;border-radius:10px;
                padding:12px 16px;margin-bottom:16px;">
                <div style="display:flex;justify-content:space-between;align-items:center;
                    margin-bottom:8px;">
                    <span style="font-size:11px;color:#858585;">Tiến độ chung sau round này</span>
                    <span style="font-size:13px;color:${progColor};font-weight:700;
                        font-family:'JetBrains Mono',monospace;">${prog}%</span>
                </div>
                <div style="height:8px;background:#252526;border-radius:4px;overflow:hidden;">
                    <div style="height:100%;width:${prog}%;background:${progColor};
                        border-radius:4px;transition:width 0.8s ease;
                        box-shadow:0 0 8px ${progColor}66;"></div>
                </div>
                ${prog >= 100 ? `<div style="font-size:10px;color:#22c55e;margin-top:6px;">
                    🎉 Developers đã hoàn thành toàn bộ task!</div>` : ''}
            </div>

            <!-- Skip button -->
            <div style="text-align:center;">
                <button onclick="skipExecuteScreen()"
                    style="background:#252526;color:#858585;border:1px solid #333;
                    border-radius:8px;padding:8px 24px;font-size:11px;cursor:pointer;
                    font-family:'JetBrains Mono',monospace;
                    transition:background 0.15s,color 0.15s;"
                    onmouseover="this.style.background='#2d2d2d';this.style.color='#ccc'"
                    onmouseout="this.style.background='#252526';this.style.color='#858585'">
                    ⏭ Skip — Vào họp ngay
                </button>
            </div>
        </div>
    </div>`;
}

/**
 * Tạo output giả lập dòng terminal cho mỗi file
 */
function generateFakeOutput(fn, r) {
    const lang = r.lang;
    let lines = [];

    if (r.status === 'ok') {
        lines = [
            `<span style="color:#22c55e;">$ run ${fn}</span>`,
            `<span style="color:#6a9955;">✓ Compiled ${lang} — no errors</span>`,
            `<span style="color:#858585;">Output: Process exited with code 0</span>`,
        ];
    } else if (r.status === 'error') {
        lines = [
            `<span style="color:#ef4444;">$ run ${fn}</span>`,
            `<span style="color:#ef4444;">✗ RuntimeError: Unexpected behavior detected</span>`,
            `<span style="color:#f59e0b;">⚠ File integrity compromised — progress blocked</span>`,
        ];
    } else {
        lines = [
            `<span style="color:#555;">$ run ${fn}</span>`,
            `<span style="color:#555;">— No tasks completed for this file</span>`,
        ];
    }

    return lines.join('<br>');
}
