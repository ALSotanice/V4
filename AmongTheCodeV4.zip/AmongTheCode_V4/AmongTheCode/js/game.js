function notify(msg, isErr = false) {
    S.notification = { msg, isErr };
    render();
    setTimeout(() => { S.notification = null; render(); }, 3500);
}

function dbg(msg) {
    S.debugLog.unshift('[' + new Date().toLocaleTimeString() + '] ' + msg);
    if (S.debugLog.length > 50) S.debugLog.pop();
    const el = document.getElementById('debug-log');
    if (el) el.innerHTML = S.debugLog.slice(0, 20).join('\n');
}

function addChatMessage(msg, type = 'player', color = null) {
    S.chatMessages.push({ msg, type, color, ts: Date.now() });
    render();
    setTimeout(() => {
        const el = document.getElementById('chat-scroll');
        if (el) el.scrollTop = el.scrollHeight;
    }, 30);
}

function broadcastChat(msg) {
    const full = S.myName + ': ' + msg;
    addChatMessage(full, 'player', S.myColor);
    sendToAll({ type: 'CHAT', name: S.myName, msg, color: S.myColor });
}

function copyText(text) {
    navigator.clipboard.writeText(text).then(() => notify('✅ Đã copy!'));
}

function fitClass(name) {
    if (name.length > 14) return 'fit-text fit-sm';
    if (name.length > 9)  return 'fit-text fit-md';
    return 'fit-text';
}

function startCountdown() {
    if (S._countdownTimer) { clearInterval(S._countdownTimer); S._countdownTimer = null; }
    S.countdown = 3;
    render();
    S._countdownTimer = setInterval(() => {
        S.countdown--;
        render();
        if (S.countdown <= 0) {
            clearInterval(S._countdownTimer);
            S._countdownTimer = null;
            S.countdown = null;
            startRolePhase();
        }
    }, 1000);
}

function startRolePhase() {
    if (S.isHost) {
        const idx             = Math.floor(Math.random() * S.players.length);
        const vibeCoderPeerId = S.players[idx].peerId;
        sendToAll({ type: 'ROLE_ASSIGN', vibeCoderPeerId });
        applyRoles(vibeCoderPeerId);
    }
}

function applyRoles(vibeCoderPeerId) {
    if (S._roleTimer) { clearInterval(S._roleTimer); S._roleTimer = null; }

    S.vibeCoderPeerId = vibeCoderPeerId;
    S.myRole          = (S.peerId === vibeCoderPeerId) ? 'injector' : 'developer';
    S.phase           = 'role';
    S.roleTimer       = 6;
    render();

    S._roleTimer = setInterval(() => {
        S.roleTimer--;
        const bar = document.getElementById('role-timer-bar');
        const txt = document.getElementById('role-timer-txt');
        if (bar) bar.style.width = ((S.roleTimer / 6) * 100) + '%';
        if (txt) txt.textContent  = S.roleTimer + 's';

        if (S.roleTimer <= 0) {
            clearInterval(S._roleTimer);
            S._roleTimer = null;
            enterCodingPhase();
        }
    }, 1000);
}

function enterCodingPhase() {
    if (S._codingTimerInterval) { clearInterval(S._codingTimerInterval); S._codingTimerInterval = null; }
    if (S._runResultTimer)      { clearInterval(S._runResultTimer);      S._runResultTimer      = null; }

    S.phase              = 'coding';
    S.roleTimer          = null;
    S.codingTimerRunning = false;
    S.showRunResult      = false;
    S.isSpectator        = false;
    S.hasVoted           = false;

    S.fileActivePlayers                = {};
    S.fileActivePlayers[S.currentFile] = [{ peerId: S.peerId || 'local', name: S.myName, color: S.myColor }];

    S.currentRound      = 1;
    S.eliminatedPlayers = [];
    S.gameWinner        = null;
    S.isForceMeeting    = false;

    initTasks();
    resetMeetingVote();
    render();

    startCodingRound();
}

function startCodingRound() {
    if (S._codingTimerInterval) { clearInterval(S._codingTimerInterval); S._codingTimerInterval = null; }
    S.codingTimer        = ROUND_DURATION;
    S.codingTimerRunning = false;
    notify(`🔔 Round ${S.currentRound}/${TOTAL_ROUNDS} — ${ROUND_DURATION / 60} phút`);
    render();
    setTimeout(startCodingTimer, 200);
}

function startCodingTimer() {
    if (S._codingTimerInterval) return;
    S.codingTimerRunning = true;
    S._codingTimerInterval = setInterval(() => {
        S.codingTimer--;

        const timerEl = document.getElementById('coding-timer-display');
        if (timerEl) {
            const m        = Math.floor(S.codingTimer / 60);
            const sec      = S.codingTimer % 60;
            const isUrgent = S.codingTimer <= 30;
            timerEl.textContent = m + ':' + String(sec).padStart(2, '0');
            timerEl.style.color = isUrgent ? '#ef4444' : '#22c55e';
            const box = document.getElementById('coding-timer-box');
            if (box) box.style.borderColor = isUrgent ? '#ef444466' : '#22c55e44';
        }

        if (S.codingTimer <= 0) {
            clearInterval(S._codingTimerInterval);
            S._codingTimerInterval = null;
            S.codingTimerRunning   = false;
            S.codingTimer          = 0;
            if (S.isHost) onRoundTimerExpired();
        }
    }, 1000);
}

function pauseCodingTimer() {
    if (S._codingTimerInterval) {
        clearInterval(S._codingTimerInterval);
        S._codingTimerInterval = null;
    }
    S.codingTimerRunning = false;
}

function endRunResult() {
    S.showRunResult  = false;
    S.voteSkipCounts = 0;
    render();
}

function voteSkip() {
    S.voteSkipCounts++;
    const needed = Math.max(1, S.players.length || 1);
    const el = document.getElementById('vote-skip-count');
    if (el) el.textContent = S.voteSkipCounts + '/' + needed;
    notify('⏭️ Đã vote skip (' + S.voteSkipCounts + '/' + needed + ')');
    if (S.voteSkipCounts >= needed) {
        if (S._runResultTimer) { clearInterval(S._runResultTimer); S._runResultTimer = null; }
        endRunResult();
    }
}

function switchFile(fn) {
    const ta = document.querySelector('#code-editor-area');
    if (ta) FILES[S.currentFile].content = ta.value;

    Object.keys(S.fileActivePlayers).forEach(f => {
        S.fileActivePlayers[f] = (S.fileActivePlayers[f] || []).filter(p => p.peerId !== (S.peerId || 'local'));
    });
    if (!S.fileActivePlayers[fn]) S.fileActivePlayers[fn] = [];
    S.fileActivePlayers[fn].push({ peerId: S.peerId || 'local', name: S.myName, color: S.myColor });

    sendToAll({ type: 'FILE_SWITCH', peerId: S.peerId || 'local', name: S.myName, color: S.myColor, file: fn });
    S.currentFile = fn;
    render();
}

let _mediaStream = null;

async function toggleVoice() {
    if (S.voiceActive) {
        if (_mediaStream) { _mediaStream.getTracks().forEach(t => t.stop()); _mediaStream = null; }
        S.voiceActive = false;
        notify('🔇 Mic đã tắt');
    } else {
        try {
            _mediaStream  = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
            S.voiceActive = true;
            notify('🎙️ Mic đang hoạt động');
        } catch (e) {
            notify('❌ Không truy cập mic: ' + e.message, true);
        }
    }
    render();
}

function cleanupRoom() {
    Object.values(S.connections).forEach(c => { try { c.close(); } catch (e) {} });
    S.connections        = {};
    S.players            = [];
    S.isHost             = false;
    S.roomId             = null;
    S.chatMessages       = [];
    S.showChat           = false;
    S.modal              = null;
    S.codingTimerRunning = false;
    S.showRunResult      = false;
    S.codingTimer        = 300;
    S.isSpectator        = false;
    S.hasVoted           = false;
    if (S._codingTimerInterval) { clearInterval(S._codingTimerInterval); S._codingTimerInterval = null; }
    if (S._runResultTimer)      { clearInterval(S._runResultTimer);      S._runResultTimer      = null; }
}