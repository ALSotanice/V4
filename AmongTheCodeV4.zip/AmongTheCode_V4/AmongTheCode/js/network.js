let _voteCollector  = null;
let _voteTimeout    = null;
let _applyingRemote = false;

function genId() {
    return Math.floor(100000 + Math.random() * 900000).toString();
}

function initPeer() {
    dbg('Initializing PeerJS...');
    updateNetworkStatus('connecting');

    const peer = new Peer(genId(), {
        host:   '0.peerjs.com',
        port:   443,
        path:   '/',
        secure: true,
        debug:  1,
        config: {
            iceServers: [
                { urls: 'stun:stun.l.google.com:19302' },
                { urls: 'stun:stun1.l.google.com:19302' },
                { urls: 'stun:stun2.l.google.com:19302' },
                { urls: 'turn:openrelay.metered.ca:80',                username: 'openrelayproject', credential: 'openrelayproject' },
                { urls: 'turn:openrelay.metered.ca:443',               username: 'openrelayproject', credential: 'openrelayproject' },
                { urls: 'turn:openrelay.metered.ca:443?transport=tcp', username: 'openrelayproject', credential: 'openrelayproject' },
            ]
        }
    });

    S.peer = peer;

    peer.on('open', id => {
        S.peerId = id;
        updateNetworkStatus('ready');
        dbg('✅ Peer ready. ID = ' + id);
        render();
    });

    peer.on('connection', conn => {
        dbg('📥 Incoming: ' + conn.peer);
        setupConn(conn);
    });

    peer.on('error', err => {
        dbg('❌ Peer error: ' + err.type + ' — ' + err.message);
        if (err.type === 'peer-unavailable') {
            notify('❌ Không tìm thấy phòng. Kiểm tra lại Room ID.', true);
        } else if (err.type === 'network' || err.type === 'server-error') {
            notify('⚠️ Mất kết nối. Thử reload trang.', true);
            updateNetworkStatus('error');
        } else {
            notify('⚠️ ' + err.type, true);
        }
        render();
    });

    peer.on('disconnected', () => {
        dbg('⚠️ Disconnected. Reconnecting...');
        updateNetworkStatus('connecting');
        setTimeout(() => { if (!S.peer.destroyed) S.peer.reconnect(); }, 2000);
    });
}

function updateNetworkStatus(status) {
    S.peerStatus = status;
    const el = document.getElementById('peer-status-bar');
    if (el) renderStatusBarInto(el);
}

function setupConn(conn) {
    conn.on('data', data => {
        dbg('📨 Recv: ' + data.type + ' from ' + conn.peer);
        handleNetworkMessage(data, conn.peer);
    });

    conn.on('close', () => {
        dbg('🔌 Closed: ' + conn.peer);
        delete S.connections[conn.peer];
        S.players = S.players.filter(p => p.peerId !== conn.peer);
        if (S.isHost) {
            sendToAll({ type: 'PLAYERS_UPDATE', players: S.players });
            if (_voteCollector) {
                _voteCollector.expected = Math.max(1, _voteCollector.expected - 1);
                _checkVoteComplete();
            }
        }
        addChatMessage('🔴 Một người chơi đã rời phòng', 'system');
        render();
    });

    conn.on('error', e => dbg('Conn error: ' + e));

    const onOpen = () => {
        dbg('🔗 Open: ' + conn.peer);
        S.connections[conn.peer] = conn;
    };
    if (conn.open) onOpen();
    else conn.on('open', onOpen);
}

function connectToPeer(targetId, onOpen) {
    dbg('🔌 Connecting to: ' + targetId);
    if (!S.peer || S.peer.destroyed) { notify('❌ Peer chưa sẵn sàng!', true); return; }
    if (S.peerStatus !== 'ready')    { notify('❌ Chờ kết nối mạng xong đã!', true); return; }

    const conn = S.peer.connect(targetId, { reliable: true, serialization: 'json' });
    setupConn(conn);
    conn.on('open',  () => onOpen(conn));
    conn.on('error', e  => { dbg('Connect error: ' + e); notify('❌ Không thể kết nối: ' + e, true); });

    setTimeout(() => {
        if (!conn.open) {
            notify('❌ Timeout. Phòng không phản hồi.', true);
            dbg('⏱ Timeout connecting to ' + targetId);
        }
    }, 8000);
}

function sendTo(peerId, data) {
    const c = S.connections[peerId];
    if (c && c.open) c.send(data);
    else dbg('⚠️ Cannot send to ' + peerId + ': not open');
}

function sendToAll(data) {
    Object.keys(S.connections).forEach(id => sendTo(id, data));
}

function handleCodeInput(el) {
    if (_applyingRemote) return;
    FILES[S.currentFile].content = el.value;
    sendToAll({ type: 'CODE_UPDATE', file: S.currentFile, content: el.value });
}

function startVoteCollection() {
    if (!S.isHost) return;
    if (_voteTimeout) { clearTimeout(_voteTimeout); _voteTimeout = null; }
    _voteCollector = { votes: {}, expected: S.players.length };
    dbg('🗳 Vote collection started — expecting ' + _voteCollector.expected);

    _voteTimeout = setTimeout(() => {
        if (!_voteCollector) return;
        dbg('⏱ Vote timeout — tallying partial votes');
        _finalizeVotes(_tallyVotes(_voteCollector.votes));
    }, 90000);
}

function submitVote(votedOutPeerId) {
    if (S.isSpectator) return;
    if (S.isHost) {
        _receiveVote(S.peerId, votedOutPeerId || null);
    } else {
        const host = S.players.find(p => p.isHost);
        if (host) sendTo(host.peerId, { type: 'VOTE_CAST', fromPeerId: S.peerId, votedOutPeerId: votedOutPeerId || null });
    }
}

function _receiveVote(fromPeerId, votedOutPeerId) {
    if (!_voteCollector) startVoteCollection();
    if (_voteCollector.votes.hasOwnProperty(fromPeerId)) return;
    _voteCollector.votes[fromPeerId] = votedOutPeerId;
    dbg('🗳 Vote from ' + fromPeerId + ': ' + (votedOutPeerId || 'skip') +
        ' (' + Object.keys(_voteCollector.votes).length + '/' + _voteCollector.expected + ')');
    _checkVoteComplete();
}

function _checkVoteComplete() {
    if (!_voteCollector) return;
    if (Object.keys(_voteCollector.votes).length >= _voteCollector.expected) {
        _finalizeVotes(_tallyVotes(_voteCollector.votes));
    }
}

function _finalizeVotes(result) {
    if (_voteTimeout) { clearTimeout(_voteTimeout); _voteTimeout = null; }
    _voteCollector = null;
    sendToAll({ type: 'VOTE_RESULT', votedOutPeerId: result });
    processVoteResult(result);
}

function _tallyVotes(votes) {
    const counts = {};
    Object.values(votes).forEach(v => { if (v) counts[v] = (counts[v] || 0) + 1; });
    const entries = Object.entries(counts).sort((a, b) => b[1] - a[1]);
    if (!entries.length) return null;
    if (entries.length >= 2 && entries[0][1] === entries[1][1]) return null;
    return entries[0][0];
}

function handleNetworkMessage(data, fromPeer) {
    switch (data.type) {

        case 'JOIN_REQUEST': {
            if (!S.isHost) return;
            if (S.players.length >= S.maxPlayers) {
                sendTo(fromPeer, { type: 'JOIN_DENIED', reason: 'Phòng đầy rồi!' });
                return;
            }
            const newPlayer = { peerId: fromPeer, name: data.name, color: data.color, avatar: data.avatar, isHost: false, readyVote: false };
            S.players.push(newPlayer);
            sendTo(fromPeer, { type: 'JOIN_ACCEPTED', players: S.players, roomName: S.roomName, maxPlayers: S.maxPlayers, roomId: S.roomId });
            sendToAll({ type: 'PLAYERS_UPDATE', players: S.players });
            addChatMessage('🟢 ' + data.name + ' đã vào phòng', 'system');
            render();
            break;
        }

        case 'JOIN_ACCEPTED': {
            S.players    = data.players;
            S.roomName   = data.roomName;
            S.maxPlayers = data.maxPlayers;
            S.roomId     = data.roomId;
            S.phase      = 'waiting';
            notify('✅ Đã vào phòng: ' + data.roomName);
            render();
            break;
        }

        case 'JOIN_DENIED': {
            notify('❌ Từ chối: ' + data.reason, true);
            break;
        }

        case 'PLAYERS_UPDATE': {
            S.players = data.players;
            render();
            break;
        }

        case 'SETTINGS_UPDATE': {
            S.roundTime   = data.roundTime;
            S.meetingTime = data.meetingTime;
            addChatMessage('⚙️ Host cập nhật cài đặt game', 'system');
            render();
            break;
        }

        case 'START_COUNTDOWN': {
            startCountdown();
            break;
        }

        case 'ROLE_ASSIGN': {
            applyRoles(data.vibeCoderPeerId);
            break;
        }

        case 'VOTE_REQUEST': {
            if (!S.isHost) return;
            S.players = S.players.map(p => p.peerId === fromPeer ? { ...p, readyVote: true } : p);
            sendToAll({ type: 'PLAYERS_UPDATE', players: S.players });
            const votes  = S.players.filter(p => p.readyVote).length;
            const needed = Math.ceil(S.players.length * 0.8);
            addChatMessage(`🗳️ Vote: ${votes}/${S.players.length} (cần ${needed})`, 'system');
            if (votes >= needed && S.players.length >= 2) {
                sendToAll({ type: 'START_COUNTDOWN' });
                startCountdown();
            }
            render();
            break;
        }

        case 'CHAT': {
            addChatMessage(data.name + ': ' + data.msg, 'player', data.color);
            break;
        }

        case 'MEETING_CHAT': {
            S.meetingChatMessages.push({ from: data.from, msg: data.msg, color: data.color });
            const el = document.getElementById('meeting-chat-scroll');
            if (el) {
                const div = document.createElement('div');
                div.style.fontSize = '10px';
                div.innerHTML = `<span style="color:${data.color || '#4fc3f7'};">${data.from}:</span> <span style="color:#d4d4d4;">${data.msg}</span>`;
                el.appendChild(div);
                el.scrollTop = el.scrollHeight;
            }
            break;
        }

        case 'CODE_UPDATE': {
            FILES[data.file].content = data.content;
            if (data.file === S.currentFile) {
                const el = document.getElementById('code-editor-area');
                if (el) {
                    _applyingRemote = true;
                    const sel = [el.selectionStart, el.selectionEnd];
                    el.value = data.content;
                    el.setSelectionRange(sel[0], sel[1]);
                    _applyingRemote = false;
                }
            }
            break;
        }

        case 'MEETING_VOTE_CAST': {
            handleMeetingVoteCast(data);
            break;
        }

        case 'MEETING_START': {
            handleMeetingStart();
            break;
        }

        case 'MEETING_CANCEL': {
            handleMeetingCancel();
            break;
        }

        case 'TASK_COMPLETED': {
            handleRemoteTaskCompleted(data);
            break;
        }

        case 'TASK_UNCOMPLETED': {
            handleRemoteTaskUncompleted(data);
            break;
        }

        case 'VOTE_CAST': {
            if (!S.isHost) return;
            _receiveVote(data.fromPeerId, data.votedOutPeerId || null);
            break;
        }

        case 'VOTE_RESULT': {
            if (S.isHost) return;
            processVoteResult(data.votedOutPeerId || null);
            break;
        }

        case 'FORCE_MEETING': {
            handleForceMeeting(data);
            break;
        }

        case 'GAME_OVER': {
            handleGameOver(data);
            break;
        }

        case 'PLAYER_ELIMINATED': {
            handlePlayerEliminated(data);
            break;
        }

        case 'FILE_SWITCH': {
            if (!S.fileActivePlayers) S.fileActivePlayers = {};
            Object.keys(S.fileActivePlayers).forEach(f => {
                S.fileActivePlayers[f] = (S.fileActivePlayers[f] || []).filter(p => p.peerId !== data.peerId);
            });
            if (!S.fileActivePlayers[data.file]) S.fileActivePlayers[data.file] = [];
            S.fileActivePlayers[data.file].push({ peerId: data.peerId, name: data.name, color: data.color });
            Object.keys(FILES).forEach(fn => {
                const dotEl = document.getElementById('file-dots-' + fn);
                if (dotEl) {
                    const players = S.fileActivePlayers[fn] || [];
                    dotEl.innerHTML = players
                        .map(p => `<div title="${p.name}" style="width:8px;height:8px;border-radius:2px;background:${p.color};flex-shrink:0;"></div>`)
                        .join('');
                }
            });
            break;
        }
    }
}