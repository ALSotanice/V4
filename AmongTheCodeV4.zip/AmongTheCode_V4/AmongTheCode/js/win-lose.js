const ROUND_DURATION = 300;
const TOTAL_ROUNDS   = 3;

function onRoundTimerExpired() {
    buildAutoRunOutput();
    if (S.isHost) {
        sendToAll({ type: 'FORCE_MEETING', terminalOutput: S.terminalOutput });
    }
    startForceMeeting();
}

function startForceMeeting() {
    pauseCodingTimer();
    resetMeetingVote();
    S.isForceMeeting = true;
    S.showRunResult  = false;
    S.selectedVote   = null;
    S.hasVoted       = false;
    notify(`⚠️ Round ${S.currentRound} kết thúc — Emergency Meeting!`);
    // Hiện màn hình Execute Code 10s rồi mới vào meeting
    startExecuteScreen(() => {
        S.showMeeting = true;
        if (S.isHost) startVoteCollection();
        render();
    });
    render();
}

function processVoteResult(votedOutPeerId) {
    if (!votedOutPeerId) {
        notify('⏭️ Không ai bị loại');
        afterMeetingEnd();
        return;
    }

    const votedPlayer = S.players.find(p => p.peerId === votedOutPeerId);
    if (!votedPlayer) { afterMeetingEnd(); return; }

    S.eliminatedPlayers.push({ ...votedPlayer, eliminatedRound: S.currentRound });
    S.players = S.players.filter(p => p.peerId !== votedOutPeerId);

    if (votedOutPeerId === S.peerId) {
        S.isSpectator = true;
        notify('👻 Bạn đã bị loại — chuyển sang Ghost Mode');
    }

    if (S.isHost) {
        sendToAll({ type: 'PLAYER_ELIMINATED', peerId: votedOutPeerId, eliminatedPlayer: votedPlayer });
        sendToAll({ type: 'PLAYERS_UPDATE', players: S.players });
    }

    notify(`🚫 ${votedPlayer.name} đã bị loại!`);
    checkWinCondition();
}

function checkWinCondition() {
    const injectorAlive = S.players.filter(p => p.peerId === S.vibeCoderPeerId);
    const devAlive      = S.players.filter(p => p.peerId !== S.vibeCoderPeerId);

    if (injectorAlive.length === 0) {
        const who = S.eliminatedPlayers.find(p => p.peerId === S.vibeCoderPeerId);
        triggerEndgame('developer', `${who ? who.name : 'Injector'} đã bị tìm ra và loại bỏ!`);
        return;
    }

    if (devAlive.length <= injectorAlive.length) {
        triggerEndgame('injector', 'Injector chiếm đa số — Developer không thể thắng!');
        return;
    }

    afterMeetingEnd();
}

function afterMeetingEnd() {
    S.showMeeting    = false;
    S.isForceMeeting = false;
    S.selectedVote   = null;
    S.hasVoted       = false;
    S.currentRound++;

    if (S.currentRound > TOTAL_ROUNDS) {
        triggerEndgame('injector', `Hết ${TOTAL_ROUNDS} cuộc họp — Injector chưa bị tìm ra!`);
        return;
    }

    startCodingRound();
}

function triggerEndgame(winner, reason) {
    if (S.phase === 'endgame') return;

    if (S._codingTimerInterval) { clearInterval(S._codingTimerInterval); S._codingTimerInterval = null; }
    if (S._runResultTimer)      { clearInterval(S._runResultTimer);      S._runResultTimer      = null; }

    S.gameWinner    = winner;
    S.gameEndReason = reason;
    S.phase         = 'endgame';
    S.showMeeting   = false;
    S.showRunResult = false;

    if (S.isHost) {
        sendToAll({
            type:              'GAME_OVER',
            winner,
            reason,
            eliminatedPlayers: S.eliminatedPlayers,
            vibeCoderPeerId:   S.vibeCoderPeerId
        });
    }
    render();
}

function handleGameOver(data) {
    if (S._codingTimerInterval) { clearInterval(S._codingTimerInterval); S._codingTimerInterval = null; }
    if (S._runResultTimer)      { clearInterval(S._runResultTimer);      S._runResultTimer      = null; }

    S.gameWinner        = data.winner;
    S.gameEndReason     = data.reason;
    S.eliminatedPlayers = data.eliminatedPlayers || [];
    S.vibeCoderPeerId   = data.vibeCoderPeerId;
    S.phase             = 'endgame';
    S.showMeeting       = false;
    render();
}

function handleForceMeeting(data) {
    S.terminalOutput = data.terminalOutput || '';
    startForceMeeting();
}

function handlePlayerEliminated(data) {
    if (S.eliminatedPlayers.find(p => p.peerId === data.peerId)) return;
    S.eliminatedPlayers.push(data.eliminatedPlayer);
    S.players = S.players.filter(p => p.peerId !== data.peerId);
    if (data.peerId === S.peerId) {
        S.isSpectator = true;
        notify('👻 Bạn đã bị loại — chuyển sang Ghost Mode');
    } else {
        notify(`🚫 ${data.eliminatedPlayer.name} đã bị loại!`);
    }
    render();
}

function buildAutoRunOutput() {
    let out = `> AUTO-RUN — Round ${S.currentRound} kết thúc\n\n`;
    Object.keys(FILES).forEach(fn => {
        const fi = FILES[fn];
        out += `── ${fn} (${fi.lang.toUpperCase()}) ──\n`;
        out += Math.random() < 0.25
            ? `❌ Error: Compilation failed\n\n`
            : `✅ OK\n` + ({ javascript: '🎮 Game started', python: '🐍 OK', java: '☕ OK', cpp: '⚙️ OK' }[fi.lang] || 'OK') + '\n\n';
    });
    out += `\nRound ${S.currentRound}/${TOTAL_ROUNDS} hoàn thành.`;
    S.terminalOutput = out;
}

function backToLobby() {
    cleanupRoom();
    S.phase             = 'lobby';
    S.gameWinner        = null;
    S.gameEndReason     = '';
    S.eliminatedPlayers = [];
    S.currentRound      = 0;
    S.isForceMeeting    = false;
    S.isSpectator       = false;
    S.hasVoted          = false;
    render();
}