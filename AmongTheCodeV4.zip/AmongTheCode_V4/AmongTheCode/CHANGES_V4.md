# Among The Code — V4 Changes

## Tổng quan
V4 thêm màn hình **"Execute Code"** — hiển thị 10 giây trước khi vào Meeting Phase,
cho phép tất cả người chơi thấy kết quả chạy code của từng file và cập nhật thanh tiến độ chung.

---

## Các file đã chỉnh sửa

### 1. `js/state.js`
**Thêm các field mới vào object `S`:**
- `showExecuteScreen` *(boolean)* — bật/tắt màn hình Execute Code
- `executeScreenSecs` *(number)* — bộ đếm ngược 10s
- `_executeAfterCb` *(function)* — callback gọi sau khi màn hình đóng
- `allCompletedDevTasks` *(Set)* — tập hợp developer task IDs đã hoàn thành từ **tất cả** players
- `allCompletedInjTasks` *(Set)* — tập hợp injector task IDs đã hoàn thành từ **tất cả** injectors

---

### 2. `js/tasks.js`
**Thêm logic broadcast task completion qua P2P:**
- `initTasks()` — khởi tạo thêm `allCompletedDevTasks` và `allCompletedInjTasks`
- `toggleTask()` — khi tick task xong, gửi message `TASK_COMPLETED` / `TASK_UNCOMPLETED` tới tất cả peers
- `handleRemoteTaskCompleted(data)` *(mới)* — nhận task completion từ peer khác, cập nhật aggregate sets
- `handleRemoteTaskUncompleted(data)` *(mới)* — nhận task uncomplete từ peer khác

**Ý nghĩa:** Aggregate sets (`allCompletedDevTasks`, `allCompletedInjTasks`) giúp màn hình Execute Code biết chính xác task nào đã được thực hiện trên toàn bộ game, không chỉ của riêng player hiện tại.

---

### 3. `js/meeting-vote.js`
**Thay đổi flow khi meeting được chấp nhận:**

Trước V4:
```
meetingVoteYes >= threshold → vào Meeting Phase ngay
```

Sau V4:
```
meetingVoteYes >= threshold → startExecuteScreen(10s) → vào Meeting Phase
```

Áp dụng cho 2 nơi:
- `checkMeetingThreshold()` — khi đủ vote "yes" từ players
- `handleMeetingStart()` — khi nhận message MEETING_START từ host

---

### 4. `js/win-lose.js`
**Thay đổi flow Force Meeting (hết giờ round):**

Trước V4:
```
onRoundTimerExpired → startForceMeeting → Meeting Phase ngay
```

Sau V4:
```
onRoundTimerExpired → startForceMeeting → startExecuteScreen(10s) → Meeting Phase
```

---

### 5. `js/network.js`
**Thêm 2 message type mới:**
- `TASK_COMPLETED` — broadcast khi một player hoàn thành task
- `TASK_UNCOMPLETED` — broadcast khi một player bỏ tick task

Route tới: `handleRemoteTaskCompleted()` và `handleRemoteTaskUncompleted()`

---

### 6. `style.css`
**Thêm animation:**
- `@keyframes fadeInRow` — hiệu ứng fade-in cho từng file row trong màn hình Execute Code

---

### 7. `index.html`
**Thêm script tag:**
- `<script src="js/ui/execute-code-ui.js"></script>` — load file UI mới

---

## File mới tạo

### `js/ui/execute-code-ui.js` *(MỚI)*
Toàn bộ logic và UI của màn hình Execute Code.

**Các hàm chính:**

| Hàm | Mô tả |
|-----|-------|
| `startExecuteScreen(callback)` | Khởi động màn hình, đếm ngược 10s, gọi callback khi xong |
| `skipExecuteScreen()` | Bỏ qua màn hình ngay lập tức (nút "Skip") |
| `renderExecuteScreen()` | Render HTML của màn hình (gọi bởi render.js) |
| `computeExecuteResults()` | Tính trạng thái từng file dựa trên tasks đã hoàn thành |
| `applyExecuteResultsToProgress(results)` | Cập nhật `S.taskProgress` sau khi tính kết quả |
| `generateFakeOutput(fn, r)` | Tạo dòng terminal giả lập cho visual effect |

**Logic phán định trạng thái file:**
- **`ok` ✅** — có ít nhất 1 developer task done, không bị inject → tiến độ được cộng
- **`error` ❌** — có injector task done trên file này → tiến độ **KHÔNG** cộng (file bị sabotage)
- **`pending` ⏳** — chưa có task nào done

---

## Cách hoạt động (End-to-End)

```
[Players coding...]
    ↓ tick task  →  broadcast TASK_COMPLETED
    ↓ peers nhận →  update allCompletedDevTasks / allCompletedInjTasks

[Meeting vote đủ / Round hết giờ]
    ↓
startExecuteScreen()
    ↓ 10 giây countdown
    ↓ Hiển thị từng file + trạng thái ok/error/pending
    ↓ Cập nhật thanh tiến độ chung (file error không cộng)
    ↓
[Enter Meeting Phase — vote loại người chơi]
```

---

## Ví dụ cụ thể

**Quest developer:** "Viết hàm initPlayer(name)" (file `main.game.js`, id `js-1`)

- Developer tick xong → `allCompletedDevTasks.add('js-1')`
- Injector **không** có task nào done trên `main.game.js`
- → Khi Execute Screen: `main.game.js` = ✅ `ok` → tiến độ cộng

**Quest injector:** "Thêm while(true){} ẩn vào hàm bất kỳ" (file `main.game.js`, id `injs-1`)

- Injector tick xong → `allCompletedInjTasks.add('injs-1')`
- → Khi Execute Screen: `main.game.js` = ❌ `error` → tiến độ **KHÔNG cộng** dù developer đã code
